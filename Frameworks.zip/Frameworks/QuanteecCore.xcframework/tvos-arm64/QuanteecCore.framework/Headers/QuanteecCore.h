//
//
// QuanteecCore.h
// QuanteecCore
//
// Created by Csongor Nagy on 08.12.2023.
// 

#import <Foundation/Foundation.h>
#import <QuanteecCore/GCDWebServerBridge.h>

//! Project version number for QuanteecCore.
FOUNDATION_EXPORT double QuanteecCoreVersionNumber;

//! Project version string for QuanteecCore.
FOUNDATION_EXPORT const unsigned char QuanteecCoreVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <QuanteecPlugin/PublicHeader.h>


